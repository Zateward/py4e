wrd = 'Banana'

#The "count" method return the number of specific terms in a word.
print(wrd.count('a'))
