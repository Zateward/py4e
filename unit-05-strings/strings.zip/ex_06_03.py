#This are the methods of the string:

print(dir('Hello'))
